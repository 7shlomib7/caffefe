import { useState, useEffect } from "react";

// ─── PARAMS DATA ─────────────────────────────────────────────────────────────
const PARAMS = [
  {
    id: "strength", label: "עוצמה", icon: "⚡",
    description: "מידת האינטנסיביות של הקפה בכוס — תלויה בכמות הקפה, שיטת ההכנה ורמת הקלייה.",
    options: ["עדין מאוד","עדין","בינוני","חזק","חזק מאוד","אקספרסו כפול"],
    optionDesc: { "עדין מאוד":"כמעט מימי, עדין מאוד — לרגישים לקפה","עדין":"קל ונעים","בינוני":"איזון קלאסי","חזק":"טעם בולט ומרוכז","חזק מאוד":"אינטנסיבי ועוצמתי","אקספרסו כפול":"מקסימום עוצמה בכמות קטנה" },
  },
  {
    id: "flavor", label: "פרופיל טעם", icon: "👅",
    description: "הטעמים שתחוש בשתייה — נובעים ממקור הפולים, שיטת העיבוד ורמת הקלייה.",
    options: ["פירותי","שוקולדי","אגוזי","פרחוני","קרמלי","ספייסי","ארצי/עפרוני","חמצמץ","וניל","טבק/עשן"],
    optionDesc: { "פירותי":"פירות יער, הדרים או טרופיים","שוקולדי":"שוקולד מריר או קקאו עמוק","אגוזי":"חמאת בוטנים, לוז, אגוז — עגול ונעים","פרחוני":"עדין וארומטי, ג׳סמין או ורדים","קרמלי":"מתיקות עמוקה של קרמל וחמאה","ספייסי":"קינמון, הל, פלפל — מזרחי","ארצי/עפרוני":"עץ, עפר לח, פטריות — כבד ועשיר","חמצמץ":"חמיצות בהירה כמו הדרים","וניל":"מתיקות עדינה וקרמית","טבק/עשן":"עומק כהה ומעושן — קלייה כהה מאוד" },
  },
  {
    id: "aroma", label: "ארומה", icon: "🌸",
    description: "עוצמת הריח העולה מהכוס — חלק מרכזי מחוויית הקפה.",
    options: ["עדינה","בינונית","אינטנסיבית","פירותית","שרופה","מתוקה","פרחונית","עצית"],
    optionDesc: { "עדינה":"ריח שקט — רק כשמקרבים","בינונית":"ריח נוכח ונעים","אינטנסיבית":"ריח עז שממלא את החדר","פירותית":"ריח פירותי מרענן","שרופה":"ריח קלוי-כהה, French Roast","מתוקה":"ריח קרמל, שוקולד, מאפה","פרחונית":"ריח ג׳סמין, ורד — אתיופיה Washed","עצית":"ריח עץ, טבאק — עמוק ובוגר" },
  },
  {
    id: "caffeine", label: "קפאין", icon: "⚗️",
    description: "רמת הקפאין בכוס — Robusta מכיל כפליים קפאין מ-Arabica.",
    options: ["ללא קפאין (Decaf)","נמוכה","בינונית","גבוהה","מקסימלית"],
    optionDesc: { "ללא קפאין (Decaf)":"97%+ הוסר — לשתייה בכל שעה","נמוכה":"Arabica בהיר — ~70mg","בינונית":"קפה יומיומי — ~100mg","גבוהה":"אספרסו כהה + Robusta — ~150mg","מקסימלית":"Robusta טהור — 200mg+" },
  },
  {
    id: "milk", label: "חלב", icon: "🥛",
    description: "החלב מרכך מרירות ומוסיף קרמיות. לכל חלב אלטרנטיבי אופי שונה לגמרי.",
    options: ["ללא חלב","חלב פרה","חלב שיבולת שועל","חלב שקדים","חלב סויה","חלב קוקוס","קצפת"],
    optionDesc: { "ללא חלב":"הקפה בטהרתו — כל הטעמים נחשפים","חלב פרה":"קרמי וסמיך — לאטה/קפוצ׳ינו מושלם","חלב שיבולת שועל":"קרמי ומתקתק — הכי פופולרי היום","חלב שקדים":"קליל עם נגיעת אגוז","חלב סויה":"ניטרלי, עשיר בחלבון","חלב קוקוס":"טעם טרופי, שמן ועשיר","קצפת":"עשירה מאוד, מוסיפה עובי ומתיקות" },
  },
  {
    id: "organic", label: "אורגני", icon: "🌿",
    description: "גידול ללא חומרי הדברה. Fair Trade מבטיח תנאים הוגנים לחקלאים.",
    options: ["לא חשוב","מועדף אורגני","אורגני בלבד","Fair Trade","אורגני + Fair Trade","Rainforest Alliance"],
    optionDesc: { "לא חשוב":"מתמקד בטעם בלבד","מועדף אורגני":"בוחר אורגני אם אפשר","אורגני בלבד":"חייב תעודת אורגני מוסמכת","Fair Trade":"מחיר הוגן לחקלאים","אורגני + Fair Trade":"גם ירוק וגם הוגן","Rainforest Alliance":"תקן סביבתי-חברתי מוביל" },
  },
  {
    id: "roast", label: "קלייה", icon: "🔥",
    description: "הקלייה שינה הכל. בהירה = פירותי וחמוץ. כהה = מריר ומעושן.",
    options: ["Light (בהירה)","Medium (בינונית)","Medium-Dark","Dark (כהה)","French / Italian"],
    optionDesc: { "Light (בהירה)":"פירותי, פרחוני, חמיצות — Single Origin","Medium (בינונית)":"האיזון המושלם — הבחירה הנפוצה","Medium-Dark":"פחות חמיצות, מתחיל טעם קלוי","Dark (כהה)":"מריר, שוקולדי כהה, גוף מלא","French / Italian":"מקסימלי — שמן על הפולים, מריר מאוד" },
  },
  {
    id: "origin", label: "מקור", icon: "🌍",
    description: "האזור שבו גדל הקפה קובע את אופיו — כמו יין, ה-terroir הוא הכל.",
    options: ["אתיופיה","קולומביה","ברזיל","קניה","גואטמלה","קוסטה ריקה","תימן","פנמה (Geisha)","ג׳אווה","הוואי (Kona)","ג׳מייקה","לא חשוב"],
    optionDesc: { "אתיופיה":"מולדת הקפה — פרחוני, פירות יער","קולומביה":"קלאסי ומאוזן — פירות, קרמל","ברזיל":"אגוזי, שוקולדי — Espresso אידיאלי","קניה":"חמיצות וינית, פירות אדומים, עז","גואטמלה":"שוקולד, אגוז, קרמל — עמוק","קוסטה ריקה":"נקי ומעודן, פירות טרופיים","תימן":"ספייסי, יין, שוקולד — עתיק","פנמה (Geisha)":"פרחוני אינטנסיבי — הנדיר והמפורסם","ג׳אווה":"ארצי, עשן, גוף כבד","הוואי (Kona)":"עדין, חלק — מהיוקרתיים בעולם","ג׳מייקה":"Blue Mountain — מאוזן ועדין","לא חשוב":"פתוח לכל מקור" },
  },
  {
    id: "body", label: "גוף", icon: "🌊",
    description: "תחושת הסמיכות על הלשון — כמו ההבדל בין מים לחלב.",
    options: ["קל ומימי","בינוני","מלא וסמיך","קרמי מאוד","Velvet"],
    optionDesc: { "קל ומימי":"זורם ושקוף — פילטר בהיר","בינוני":"נוכחות מורגשת אבל לא כבדה","מלא וסמיך":"הקפה יושב בפה, כבד ועשיר","קרמי מאוד":"כמו שוקולד חם — עטיפה בפה","Velvet":"קטיפתי ומשיי — האספרסו הנדיר" },
  },
  {
    id: "acidity", label: "חומציות", icon: "🍋",
    description: "חומציות טובה = עירנות ורעננות — לא חמיצות לא נעימה.",
    options: ["ללא חומציות","נמוכה","בינונית","גבוהה","בהירה ומרעננת"],
    optionDesc: { "ללא חומציות":"חלק לגמרי — לקיבות רגישות","נמוכה":"כמעט ולא מורגשת","בינונית":"חומציות נעימה שמוסיפה עניין","גבוהה":"בולטת — בצדדי הלשון","בהירה ומרעננת":"ברורה כמו הדרים — קלייה בהירה" },
  },
  {
    id: "sweetness", label: "מתיקות", icon: "🍯",
    description: "מתיקות טבעית של הפולים — ללא סוכר. נשמרת בקלייה נכונה.",
    options: ["ללא מתיקות","קצת מתוק","בינוני","מתוק","מתוק מאוד"],
    optionDesc: { "ללא מתיקות":"מריר נקי — קלייה כהה","קצת מתוק":"נגיעת מתיקות עדינה ברקע","בינוני":"מתיקות מורגשת, קרמלית","מתוק":"Natural Process מצטיין","מתוק מאוד":"כמו פרי בשל — Natural אתיופי" },
  },
  {
    id: "preparation", label: "הכנה", icon: "☕",
    description: "שיטת ההכנה קובעת את הטעם לא פחות מהפולים.",
    options: ["אספרסו","פילטר / V60","פרנץ׳ פרס","אירופרס","מוקה פוט","Cold Brew","Chemex","קפה טורקי","Drip מכונה"],
    optionDesc: { "אספרסו":"לחץ גבוה, 30 שניות, קרמה — ריכוז מקסימלי","פילטר / V60":"מסנן נייר — קפה נקי וצלול","פרנץ׳ פרס":"שרייה 4 דק׳ — גוף מלא, קצת שאריות","אירופרס":"לחץ ידני ורסטילי — נקי וחזק","מוקה פוט":"קיטור — אספרסו ביתי קלאסי","Cold Brew":"שרייה 12-24 שעות — מתוק, חלק, פחות חמיצות","Chemex":"מסנן עבה — נקי מאוד, פחות שמן","קפה טורקי":"טחון אבק, לא מסוננן — עז וסמיך","Drip מכונה":"נוח ועקבי, קפה יומיומי אמריקאי" },
  },
  {
    id: "grind", label: "טחינה", icon: "⚙️",
    description: "גודל חלקיקי הטחינה — הגורם הכי קריטי לטעם לאחר הפולים.",
    options: ["עדינה מאוד (Espresso)","עדינה (Moka)","בינונית (Drip)","בינונית-גסה (V60)","גסה (French Press)","גסה מאוד (Cold Brew)","לפי המלצה"],
    optionDesc: { "עדינה מאוד (Espresso)":"כמו אבקה — לחץ גבוה מחלץ מהר","עדינה (Moka)":"קצת פחות — לסיר הביתי","בינונית (Drip)":"כמו סוכר — למכונת פילטר","בינונית-גסה (V60)":"כמו מלח גס — 3-4 דקות","גסה (French Press)":"שרייה ארוכה — גוף מלא","גסה מאוד (Cold Brew)":"כמעט שלם — שרייה של שעות","לפי המלצה":"הAI ממליץ לפי שאר הבחירות" },
  },
  {
    id: "process", label: "עיבוד", icon: "🫒",
    description: "השלב בין קטיף הדובדבן לפול הירוק — משפיע דרמטית על הטעם.",
    options: ["Natural (יבש)","Washed (רטוב)","Honey Process","Anaerobic","לא חשוב"],
    optionDesc: { "Natural (יבש)":"מיובש שלם — מוסיף מתיקות ופירות","Washed (רטוב)":"קליפה מוסרת — קפה נקי וחמוץ","Honey Process":"בינוני — בין Natural ל-Washed","Anaerobic":"תסיסה מיוחדת — טעמים מורכבים ויוצאי דופן","לא חשוב":"לא מתמקד בשיטת עיבוד" },
  },
];

const MAX_SEL = 3;

// ─── AI PROMPT ───────────────────────────────────────────────────────────────
const buildPrompt = (selText, freeText, loc) => `
אתה מומחה קפה בכיר, Q-Grader מוסמך, עם ידע עמוק בשוק הקפה הישראלי והעולמי.

המשתמש מחפש קפה עם המאפיינים הבאים:
${freeText ? `תיאור חופשי: "${freeText}"` : ""}
${selText}
${loc ? `מיקום: ${loc}` : ""}

ענה ב-JSON בלבד ללא backticks:
{
  "coffeeMatch": {
    "name": "שם הקפה האידיאלי",
    "description": "תיאור עשיר ומלא של הקפה",
    "whyMatch": "למה זה מתאים בדיוק"
  },
  "beansGuide": {
    "generalGrindGuide": "מדריך טחינה כללי קצר",
    "storageTip": "טיפ אחסון קצר",
    "freshnessTip": "טיפ טריות קצר",
    "recommendedBeans": [
      {
        "name": "שם הפולים הספציפי",
        "variety": "זן הקפה",
        "origin": "מדינה + אזור",
        "roaster": "קולה ישראלית או בינלאומית ידועה",
        "roastLevel": "רמת הקלייה",
        "process": "שיטת עיבוד",
        "flavorNotes": "טעמים ספציפיים",
        "grindRecommendation": {
          "method": "שיטת הכנה",
          "grindSize": "דרגת טחינה",
          "grindDescription": "תיאור מרקם",
          "microns": "טווח ניקרונים"
        },
        "brewingInstructions": {
          "ratio": "יחס קפה:מים",
          "waterTemp": "טמפרטורה",
          "brewTime": "זמן",
          "steps": "הוראות קצרות"
        },
        "price": "מחיר משוער",
        "available": "היכן לרכוש",
        "tip": "טיפ מקצועי"
      }
    ]
  },
  "cafesNearby": [
    { "name": "שם", "area": "עיר/שכונה", "specialty": "מה מיוחד", "coffeeType": "סוגי קפה", "distance": "קרוב/בינוני/רחוק", "address": "כתובת" }
  ],
  "onlineOrder": [
    { "name": "שם", "country": "ישראל/אחר", "description": "תיאור", "shipsTo": "שליחות", "url": "קישור", "price": "מחיר" }
  ]
}
`;

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function CoffeeFinder() {
  const [screen, setScreen] = useState("intro"); // intro | configure | result
  const [sel, setSel] = useState({});
  const [freeText, setFreeText] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [locName, setLocName] = useState("");
  const [showParamInfo, setShowParamInfo] = useState(false);

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(pos => {
      fetch(`https://nominatim.openstreetmap.org/reverse?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&format=json`)
        .then(r => r.json()).then(d => setLocName(d.address?.city || d.address?.town || "")).catch(() => {});
    }, () => {});
  }, []);

  const toggle = (id, val) => {
    setSel(prev => {
      const cur = prev[id] || [];
      if (cur.includes(val)) return { ...prev, [id]: cur.filter(v => v !== val) || undefined };
      if (cur.length >= MAX_SEL) return prev;
      return { ...prev, [id]: [...cur, val] };
    });
  };

  const isOn = (id, val) => (sel[id] || []).includes(val);
  const cnt = id => (sel[id] || []).length;
  const totalFilled = Object.values(sel).filter(v => v?.length).length;
  const pct = Math.round((totalFilled / PARAMS.length) * 100);
  const canSearch = totalFilled >= 1 || freeText.trim().length > 3;
  const activeParam = PARAMS[activeIdx];

  const search = async () => {
    setLoading(true); setError(""); setResult(null);
    try {
      const selText = Object.entries(sel)
        .filter(([, v]) => v?.length)
        .map(([k, v]) => `${PARAMS.find(p => p.id === k)?.label || k}: ${v.join(", ")}`)
        .join("\n");

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: buildPrompt(selText, freeText, locName) }],
        }),
      });
      const data = await res.json();
      const txt = data.content?.filter(b => b.type === "text").map(b => b.text).join("") || "";
      const clean = txt.replace(/```json|```/g, "").trim();
      const s = clean.indexOf("{"), e = clean.lastIndexOf("}");
      if (s === -1) throw new Error("No JSON");
      setResult(JSON.parse(clean.slice(s, e + 1)));
      setScreen("result");
    } catch {
      setError("שגיאה בטעינת ההמלצות — נסה שוב");
    } finally { setLoading(false); }
  };

  // ── STYLES ──
  const css = `
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap');
    *{box-sizing:border-box;margin:0;padding:0}
    :root{
      --gold:#D4A843;--gold-dim:rgba(212,168,67,0.15);--gold-border:rgba(212,168,67,0.25);
      --bg:#0C0A06;--surface:rgba(255,255,255,0.04);--surface2:rgba(255,255,255,0.07);
      --text:#F5EDD8;--muted:#8A7355;--muted2:#5A4A30;
    }
    body{background:var(--bg)}
    .app{min-height:100vh;background:radial-gradient(ellipse 80% 50% at 50% -10%,rgba(212,168,67,0.12) 0%,transparent 70%),var(--bg);font-family:'DM Sans',sans-serif;color:var(--text);direction:rtl}
    .display{font-family:'Playfair Display',serif}
    /* Buttons */
    .btn-primary{background:linear-gradient(135deg,#D4A843,#A07820);color:#0C0A06;border:none;border-radius:50px;padding:16px 48px;font-size:16px;font-weight:700;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all 0.25s;box-shadow:0 8px 32px rgba(212,168,67,0.35)}
    .btn-primary:hover{transform:translateY(-2px);box-shadow:0 12px 40px rgba(212,168,67,0.45)}
    .btn-primary:disabled{opacity:0.4;cursor:not-allowed;transform:none}
    .btn-ghost{background:transparent;border:1px solid var(--gold-border);color:var(--gold);border-radius:50px;padding:10px 24px;font-size:14px;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all 0.2s}
    .btn-ghost:hover{background:var(--gold-dim);border-color:var(--gold)}
    /* Option chips */
    .chip{border:1px solid rgba(255,255,255,0.1);background:var(--surface);border-radius:12px;padding:10px 16px;font-size:13.5px;color:#C8A87A;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all 0.18s;text-align:right}
    .chip:hover:not(:disabled){border-color:var(--gold-border);background:var(--gold-dim);color:var(--text)}
    .chip.on{background:linear-gradient(135deg,rgba(212,168,67,0.25),rgba(160,120,32,0.2));border-color:var(--gold);color:var(--gold);font-weight:600}
    .chip:disabled{opacity:0.3;cursor:not-allowed}
    /* Cards */
    .card{background:var(--surface);border:1px solid rgba(255,255,255,0.08);border-radius:20px;padding:22px;transition:border-color 0.2s}
    .card:hover{border-color:var(--gold-border)}
    /* Tag */
    .tag{display:inline-flex;align-items:center;gap:4px;background:var(--gold-dim);border:1px solid var(--gold-border);border-radius:8px;padding:3px 10px;font-size:12px;color:var(--gold)}
    /* Animations */
    @keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
    @keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
    @keyframes spin{to{transform:rotate(360deg)}}
    .anim-up{animation:fadeUp 0.5s ease both}
    .anim-up-1{animation:fadeUp 0.5s 0.1s ease both}
    .anim-up-2{animation:fadeUp 0.5s 0.2s ease both}
    .anim-up-3{animation:fadeUp 0.5s 0.3s ease both}
    /* Progress ring */
    .ring-bg{stroke:rgba(255,255,255,0.08)}
    .ring-fg{stroke:var(--gold);stroke-linecap:round;transition:stroke-dashoffset 0.6s ease}
    /* Info box */
    .info-box{background:rgba(212,168,67,0.07);border:1px solid rgba(212,168,67,0.2);border-radius:12px;padding:12px 16px;font-size:13px;color:#9A7840;line-height:1.7;border-right:3px solid rgba(212,168,67,0.5)}
    /* Textarea */
    textarea{width:100%;background:var(--surface2);border:1px solid rgba(255,255,255,0.1);border-radius:14px;padding:14px 16px;color:var(--text);font-size:14px;font-family:'DM Sans',sans-serif;resize:vertical;direction:rtl;min-height:80px;transition:border 0.2s,box-shadow 0.2s;outline:none}
    textarea:focus{border-color:var(--gold-border);box-shadow:0 0 0 3px rgba(212,168,67,0.1)}
    textarea::placeholder{color:var(--muted2)}
    /* Scrollbar */
    ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(212,168,67,0.2);border-radius:2px}
    /* Loading dots */
    .dot{width:8px;height:8px;border-radius:50%;background:var(--gold);animation:bounce 1.2s infinite ease-in-out}
    .dot:nth-child(2){animation-delay:0.2s}.dot:nth-child(3){animation-delay:0.4s}
    @keyframes bounce{0%,80%,100%{transform:scale(0.6);opacity:0.4}40%{transform:scale(1);opacity:1}}
    a{color:var(--gold);text-decoration:none}a:hover{text-decoration:underline}
  `;

  const circumference = 2 * Math.PI * 20;
  const dashOffset = circumference - (pct / 100) * circumference;

  // ── INTRO ──────────────────────────────────────────────────────────────────
  if (screen === "intro") return (
    <div className="app">
      <style>{css}</style>
      <div style={{ maxWidth: 520, margin: "0 auto", padding: "60px 24px", textAlign: "center" }}>
        <div className="anim-up" style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 64, marginBottom: 16, filter: "drop-shadow(0 8px 24px rgba(212,168,67,0.5))" }}>☕</div>
          <h1 className="display anim-up-1" style={{ fontSize: "clamp(32px,8vw,52px)", fontWeight: 900, color: "#F5EDD8", lineHeight: 1.1, marginBottom: 12 }}>
            מוצא הקפה<br /><span style={{ color: "#D4A843" }}>המושלם</span>
          </h1>
          <p className="anim-up-2" style={{ fontSize: 16, color: "#8A7355", lineHeight: 1.7, marginBottom: 32 }}>
            תאר את הקפה שחלמת עליו — ונמצא לך את הפולים, הקלייה, הטחינה ואופן ההכנה המדויקים.
          </p>
        </div>

        <div className="anim-up-2" style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 36 }}>
          {[
            { icon: "🎛️", text: "14 פרמטרים — בחר עד 3 בכל אחד" },
            { icon: "🫘", text: "פולים מומלצים עם קלייה, טחינה והכנה" },
            { icon: "🏪", text: "בתי קפה ומקומות לרכישה" },
          ].map(f => (
            <div key={f.text} style={{ display: "flex", alignItems: "center", gap: 14, background: "rgba(255,255,255,0.04)", borderRadius: 14, padding: "14px 18px", border: "1px solid rgba(255,255,255,0.07)" }}>
              <span style={{ fontSize: 22 }}>{f.icon}</span>
              <span style={{ fontSize: 14, color: "#C8A87A" }}>{f.text}</span>
            </div>
          ))}
        </div>

        {locName && (
          <div className="anim-up-3" style={{ marginBottom: 24, fontSize: 13, color: "#6A4A30" }}>
            📍 מיקום זוהה: <span style={{ color: "#D4A843" }}>{locName}</span>
          </div>
        )}

        <button className="btn-primary anim-up-3" onClick={() => setScreen("configure")}>
          בוא נמצא את הקפה שלך →
        </button>
      </div>
    </div>
  );

  // ── LOADING ────────────────────────────────────────────────────────────────
  if (loading) return (
    <div className="app">
      <style>{css}</style>
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 24 }}>
        <div style={{ fontSize: 48 }}>☕</div>
        <div style={{ display: "flex", gap: 8 }}>
          <div className="dot" /><div className="dot" /><div className="dot" />
        </div>
        <p style={{ color: "#8A7355", fontSize: 15 }}>מנתח את ההעדפות שלך...</p>
      </div>
    </div>
  );

  // ── CONFIGURE ──────────────────────────────────────────────────────────────
  if (screen === "configure") return (
    <div className="app">
      <style>{css}</style>
      <div style={{ maxWidth: 680, margin: "0 auto", padding: "0 16px 80px" }}>

        {/* Top bar */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "20px 0 16px", position: "sticky", top: 0, background: "linear-gradient(to bottom,#0C0A06 80%,transparent)", zIndex: 10 }}>
          <button className="btn-ghost" onClick={() => setScreen("intro")} style={{ padding: "8px 16px", fontSize: 13 }}>← חזור</button>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <svg width="48" height="48" style={{ transform: "rotate(-90deg)" }}>
              <circle cx="24" cy="24" r="20" fill="none" strokeWidth="3" className="ring-bg" />
              <circle cx="24" cy="24" r="20" fill="none" strokeWidth="3" className="ring-fg"
                strokeDasharray={circumference} strokeDashoffset={dashOffset} />
            </svg>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: "#D4A843", lineHeight: 1 }}>{pct}%</div>
              <div style={{ fontSize: 11, color: "#5A4A30" }}>{totalFilled}/{PARAMS.length}</div>
            </div>
          </div>
        </div>

        {/* Free text */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ display: "block", fontSize: 13, color: "#8A7355", marginBottom: 8, fontWeight: 500 }}>
            ✍️ תאר בחופשיות (אופציונלי)
          </label>
          <textarea
            value={freeText}
            onChange={e => setFreeText(e.target.value)}
            placeholder="למשל: קפה חזק, שוקולדי, מעט חמיצות, עם חלב שיבולת שועל..."
          />
        </div>

        {/* Category scroll tabs */}
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 12, marginBottom: 16, scrollbarWidth: "none" }}>
          {PARAMS.map((p, i) => {
            const n = cnt(p.id);
            const active = activeIdx === i;
            return (
              <button key={p.id} onClick={() => setActiveIdx(i)} style={{
                flexShrink: 0, background: active ? "linear-gradient(135deg,rgba(212,168,67,0.2),rgba(160,120,32,0.1))" : "var(--surface)",
                border: `1px solid ${active ? "var(--gold)" : "rgba(255,255,255,0.08)"}`,
                borderRadius: 12, padding: "8px 14px", fontSize: 12.5, color: active ? "#D4A843" : "#6A4A30",
                cursor: "pointer", fontFamily: "'DM Sans',sans-serif", transition: "all 0.18s",
                display: "flex", alignItems: "center", gap: 6, fontWeight: active ? 600 : 400,
              }}>
                {p.icon} {p.label}
                {n > 0 && <span style={{ background: "#D4A843", color: "#0C0A06", borderRadius: 6, padding: "1px 7px", fontSize: 11, fontWeight: 700 }}>{n}</span>}
              </button>
            );
          })}
        </div>

        {/* Active param panel */}
        <div className="anim-up" key={activeIdx} style={{ background: "var(--surface)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 22, padding: "22px 20px", marginBottom: 20 }}>
          {/* Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 22 }}>{activeParam.icon}</span>
              <h2 className="display" style={{ fontSize: 20, color: "#F5EDD8", fontWeight: 700 }}>{activeParam.label}</h2>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <button onClick={() => setShowParamInfo(v => !v)} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, width: 28, height: 28, cursor: "pointer", color: "#6A4A30", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center" }}>?</button>
              <span style={{ fontSize: 12, color: cnt(activeParam.id) >= MAX_SEL ? "#D4A843" : "#4A3A20" }}>
                {cnt(activeParam.id)}/{MAX_SEL}
              </span>
            </div>
          </div>

          {/* Param description (toggle) */}
          {showParamInfo && activeParam.description && (
            <div className="info-box" style={{ marginBottom: 14 }}>{activeParam.description}</div>
          )}

          {/* Options */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {activeParam.options.map(opt => {
              const on = isOn(activeParam.id, opt);
              const disabled = !on && cnt(activeParam.id) >= MAX_SEL;
              const desc = activeParam.optionDesc?.[opt];
              return (
                <button key={opt} className={`chip ${on ? "on" : ""}`} disabled={disabled} onClick={() => toggle(activeParam.id, opt)}
                  style={{ display: "flex", justifyContent: "space-between", alignItems: on && desc ? "flex-start" : "center", flexDirection: on && desc ? "column" : "row", gap: on && desc ? 4 : 0, opacity: disabled ? 0.3 : 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, width: "100%" }}>
                    <span style={{ width: 18, height: 18, borderRadius: 6, border: `2px solid ${on ? "#D4A843" : "rgba(255,255,255,0.15)"}`, background: on ? "#D4A843" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.18s" }}>
                      {on && <span style={{ color: "#0C0A06", fontSize: 11, fontWeight: 800 }}>✓</span>}
                    </span>
                    <span style={{ flex: 1, textAlign: "right" }}>{opt}</span>
                  </div>
                  {desc && <div style={{ fontSize: 12, color: on ? "rgba(212,168,67,0.7)" : "#4A3A20", lineHeight: 1.5, paddingRight: 26, textAlign: "right" }}>{desc}</div>}
                </button>
              );
            })}
          </div>

          {/* Clear */}
          {cnt(activeParam.id) > 0 && (
            <button onClick={() => setSel(prev => ({ ...prev, [activeParam.id]: undefined }))} style={{ marginTop: 12, background: "none", border: "none", color: "#4A3A20", cursor: "pointer", fontSize: 12, fontFamily: "'DM Sans',sans-serif" }}>
              נקה בחירות ×
            </button>
          )}

          {/* Prev / Next nav */}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 18, gap: 10 }}>
            <button className="btn-ghost" onClick={() => setActiveIdx(i => Math.max(0, i - 1))} disabled={activeIdx === 0} style={{ fontSize: 13, padding: "8px 18px", opacity: activeIdx === 0 ? 0.3 : 1 }}>← הקודם</button>
            {activeIdx < PARAMS.length - 1
              ? <button className="btn-ghost" onClick={() => setActiveIdx(i => i + 1)} style={{ fontSize: 13, padding: "8px 18px" }}>הבא →</button>
              : <span style={{ fontSize: 12, color: "#4A3A20", alignSelf: "center" }}>✅ כל הפרמטרים</span>
            }
          </div>
        </div>

        {/* Summary of selections */}
        {totalFilled > 0 && (
          <div style={{ marginBottom: 20, padding: "14px 16px", background: "rgba(212,168,67,0.05)", borderRadius: 14, border: "1px solid rgba(212,168,67,0.12)" }}>
            <div style={{ fontSize: 12, color: "#6A4A30", marginBottom: 8 }}>הבחירות שלך:</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {Object.entries(sel).filter(([, v]) => v?.length).map(([k, v]) => {
                const p = PARAMS.find(x => x.id === k);
                return v.map(val => <span key={k + val} className="tag">{p?.icon} {val}</span>);
              })}
            </div>
          </div>
        )}

        {/* Search button */}
        <div style={{ textAlign: "center" }}>
          {canSearch
            ? <button className="btn-primary" onClick={search} style={{ width: "100%", maxWidth: 400, padding: "18px 0", fontSize: 17 }}>
                ☕ מצא לי את הקפה המושלם
              </button>
            : <p style={{ color: "#4A3A20", fontSize: 13 }}>בחר לפחות אפשרות אחת כדי להמשיך</p>
          }
          {error && <p style={{ color: "#E87A7A", marginTop: 12, fontSize: 13 }}>{error}</p>}
        </div>
      </div>
    </div>
  );

  // ── RESULT ─────────────────────────────────────────────────────────────────
  if (screen === "result" && result) return (
    <div className="app">
      <style>{css}</style>
      <div style={{ maxWidth: 680, margin: "0 auto", padding: "0 16px 80px" }}>

        {/* Top nav */}
        <div style={{ display: "flex", justifyContent: "space-between", padding: "20px 0 24px" }}>
          <button className="btn-ghost" onClick={() => setScreen("configure")} style={{ fontSize: 13, padding: "8px 16px" }}>← ערוך</button>
          <button className="btn-ghost" onClick={() => { setSel({}); setFreeText(""); setScreen("intro"); setResult(null); }} style={{ fontSize: 13, padding: "8px 16px" }}>חיפוש חדש</button>
        </div>

        {/* Hero match */}
        <div className="anim-up" style={{ textAlign: "center", marginBottom: 32, padding: "32px 24px", background: "linear-gradient(135deg,rgba(212,168,67,0.12),rgba(160,100,10,0.06))", borderRadius: 24, border: "1px solid rgba(212,168,67,0.25)" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>✨</div>
          <h2 className="display" style={{ fontSize: "clamp(22px,5vw,32px)", color: "#F5EDD8", marginBottom: 12, lineHeight: 1.2 }}>
            {result.coffeeMatch?.name}
          </h2>
          <p style={{ fontSize: 15, color: "#C8A87A", lineHeight: 1.8, marginBottom: 16 }}>
            {result.coffeeMatch?.description}
          </p>
          <div style={{ display: "inline-block", background: "rgba(212,168,67,0.1)", borderRadius: 12, padding: "10px 18px", fontSize: 13.5, color: "#D4A843", maxWidth: 480 }}>
            💡 {result.coffeeMatch?.whyMatch}
          </div>
        </div>

        {/* Beans guide */}
        {result.beansGuide && (
          <div className="anim-up-1" style={{ marginBottom: 28 }}>
            <h3 className="display" style={{ fontSize: 22, color: "#F5EDD8", marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
              🫘 <span>פולים מומלצים לרכישה</span>
            </h3>

            {/* Quick tips */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))", gap: 10, marginBottom: 18 }}>
              {[
                { icon: "⚙️", label: "טחינה", text: result.beansGuide.generalGrindGuide },
                { icon: "📦", label: "אחסון", text: result.beansGuide.storageTip },
                { icon: "📅", label: "טריות", text: result.beansGuide.freshnessTip },
              ].filter(t => t.text).map(t => (
                <div key={t.label} style={{ background: "var(--surface)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "14px" }}>
                  <div style={{ fontSize: 20, marginBottom: 6 }}>{t.icon}</div>
                  <div style={{ fontSize: 11, color: "#D4A843", fontWeight: 600, marginBottom: 4 }}>{t.label}</div>
                  <div style={{ fontSize: 12.5, color: "#8A7355", lineHeight: 1.6 }}>{t.text}</div>
                </div>
              ))}
            </div>

            {/* Bean cards */}
            {result.beansGuide.recommendedBeans?.map((bean, i) => (
              <BeanCard key={i} bean={bean} idx={i} />
            ))}
          </div>
        )}

        {/* Cafes */}
        {result.cafesNearby?.length > 0 && (
          <div className="anim-up-2" style={{ marginBottom: 28 }}>
            <h3 className="display" style={{ fontSize: 22, color: "#F5EDD8", marginBottom: 14, display: "flex", alignItems: "center", gap: 10 }}>🏪 <span>בתי קפה</span></h3>
            {result.cafesNearby.map((c, i) => (
              <div key={i} className="card" style={{ marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <h4 style={{ fontSize: 16, color: "#F5EDD8", fontWeight: 600 }}>{c.name}</h4>
                  {c.distance && <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 8, background: c.distance === "קרוב" ? "rgba(100,200,100,0.1)" : "var(--gold-dim)", color: c.distance === "קרוב" ? "#70C870" : "#D4A843", border: `1px solid ${c.distance === "קרוב" ? "rgba(100,200,100,0.2)" : "var(--gold-border)"}` }}>{c.distance}</span>}
                </div>
                {c.area && <p style={{ fontSize: 13, color: "#6A4A30", marginBottom: 4 }}>📍 {c.area}{c.address ? ` — ${c.address}` : ""}</p>}
                {c.specialty && <p style={{ fontSize: 13.5, color: "#C8A87A" }}>✨ {c.specialty}</p>}
                {c.coffeeType && <p style={{ fontSize: 12.5, color: "#5A4A30", marginTop: 4 }}>☕ {c.coffeeType}</p>}
              </div>
            ))}
          </div>
        )}

        {/* Online */}
        {result.onlineOrder?.length > 0 && (
          <div className="anim-up-3" style={{ marginBottom: 28 }}>
            <h3 className="display" style={{ fontSize: 22, color: "#F5EDD8", marginBottom: 14, display: "flex", alignItems: "center", gap: 10 }}>📦 <span>הזמנה אונליין</span></h3>
            {result.onlineOrder.map((s, i) => (
              <div key={i} className="card" style={{ marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                  <h4 style={{ fontSize: 16, color: "#F5EDD8", fontWeight: 600 }}>{s.name}</h4>
                  {s.country && <span className="tag">{s.country === "ישראל" ? "🇮🇱" : "🌐"} {s.country}</span>}
                </div>
                {s.description && <p style={{ fontSize: 13.5, color: "#C8A87A", marginBottom: 6 }}>{s.description}</p>}
                {s.shipsTo && <p style={{ fontSize: 12.5, color: "#6A4A30", marginBottom: 4 }}>🚚 {s.shipsTo}</p>}
                {s.price && <p style={{ fontSize: 13, color: "#D4A843" }}>{s.price}</p>}
                {s.url && s.url.startsWith("http") && <a href={s.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 13, display: "block", marginTop: 8 }}>🔗 לאתר הקנייה</a>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return null;
}

// ─── BEAN CARD ────────────────────────────────────────────────────────────────
function BeanCard({ bean, idx }) {
  const [open, setOpen] = useState(idx === 0);
  return (
    <div style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${open ? "rgba(212,168,67,0.35)" : "rgba(255,255,255,0.08)"}`, borderRadius: 20, marginBottom: 12, overflow: "hidden", transition: "border-color 0.2s" }}>
      {/* Header */}
      <div style={{ padding: "18px 20px", cursor: "pointer", display: "flex", alignItems: "flex-start", gap: 14 }} onClick={() => setOpen(o => !o)}>
        <div style={{ width: 32, height: 32, borderRadius: 10, background: "linear-gradient(135deg,#D4A843,#A07820)", display: "flex", alignItems: "center", justifyContent: "center", color: "#0C0A06", fontWeight: 800, fontSize: 14, flexShrink: 0 }}>{idx + 1}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h4 style={{ fontSize: 16, color: "#F5EDD8", fontWeight: 600, marginBottom: 3 }}>{bean.name}</h4>
          {bean.variety && <div style={{ fontSize: 12, color: "#5A4A30" }}>{bean.variety}</div>}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginTop: 8 }}>
            {bean.origin && <span className="tag">🌍 {bean.origin}</span>}
            {bean.roastLevel && <span className="tag">🔥 {bean.roastLevel}</span>}
            {bean.process && <span className="tag">🫒 {bean.process}</span>}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6, flexShrink: 0 }}>
          {bean.price && <span style={{ fontSize: 13, color: "#D4A843" }}>{bean.price}</span>}
          <span style={{ fontSize: 18, color: "#4A3A20", transition: "transform 0.25s", display: "block", transform: open ? "rotate(180deg)" : "none" }}>▾</span>
        </div>
      </div>

      {/* Expanded */}
      {open && (
        <div style={{ padding: "0 20px 20px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          {bean.flavorNotes && (
            <div style={{ padding: "12px 0", fontSize: 13.5, color: "#C8A87A" }}>
              <span style={{ color: "#6A4A30" }}>טעמים: </span>{bean.flavorNotes}
            </div>
          )}

          {/* Grind */}
          {bean.grindRecommendation && (
            <div style={{ background: "rgba(212,168,67,0.07)", border: "1px solid rgba(212,168,67,0.18)", borderRadius: 14, padding: "14px 16px", marginBottom: 12 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#D4A843", marginBottom: 10 }}>⚙️ המלצת טחינה</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px 16px", fontSize: 13 }}>
                {[["שיטת הכנה", bean.grindRecommendation.method], ["דרגת טחינה", bean.grindRecommendation.grindSize], ["מרקם", bean.grindRecommendation.grindDescription], ["גודל (מיקרון)", bean.grindRecommendation.microns]]
                  .filter(([, v]) => v).map(([k, v]) => (
                    <div key={k} style={{ gridColumn: k === "מרקם" ? "1/-1" : "auto" }}>
                      <span style={{ color: "#5A4A30" }}>{k}: </span>
                      <span style={{ color: "#D4C090" }}>{v}</span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Brewing */}
          {bean.brewingInstructions && (
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "14px 16px", marginBottom: 12 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#C8A87A", marginBottom: 10 }}>☕ אופן הכנה</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px 16px", fontSize: 13, marginBottom: bean.brewingInstructions.steps ? 10 : 0 }}>
                {[["יחס", bean.brewingInstructions.ratio], ["טמפרטורה", bean.brewingInstructions.waterTemp], ["זמן", bean.brewingInstructions.brewTime]]
                  .filter(([, v]) => v).map(([k, v]) => (
                    <div key={k}><span style={{ color: "#5A4A30" }}>{k}: </span><span style={{ color: "#D4C090" }}>{v}</span></div>
                  ))}
              </div>
              {bean.brewingInstructions.steps && (
                <div style={{ fontSize: 13, color: "#8A7355", lineHeight: 1.7, borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 10 }}>
                  {bean.brewingInstructions.steps}
                </div>
              )}
            </div>
          )}

          {/* Footer */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center" }}>
            {bean.roaster && <span style={{ fontSize: 13, color: "#6A4A30" }}>🔥 {bean.roaster}</span>}
            {bean.available && <span style={{ fontSize: 13, color: "#6A4A30" }}>📍 {bean.available}</span>}
            {bean.url && bean.url.startsWith("http") && <a href={bean.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 13 }}>🔗 לאתר</a>}
          </div>

          {bean.tip && (
            <div style={{ marginTop: 12, fontSize: 13, color: "#D4A843", background: "rgba(212,168,67,0.06)", borderRadius: 10, padding: "10px 14px" }}>
              💡 {bean.tip}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
